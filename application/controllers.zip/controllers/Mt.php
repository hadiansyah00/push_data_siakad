<?php
class Mt extends CI_Controller
{

	public function index()
	{
		$this->load->view('under');

		// $this->load->view('login_baak');
	}
}
